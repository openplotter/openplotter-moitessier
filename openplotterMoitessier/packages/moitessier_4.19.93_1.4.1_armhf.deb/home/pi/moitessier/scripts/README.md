Scripts
=======

These scripts are part of the Moitessier HAT project.
https://github.com/mr-rooney/moitessier


fw_update_moitessier
--------------------
Is used to update the firmware of the Moitessier HAT microcontroller.

load_driver_moitessier
----------------------
Is used to load the Moitessier HAT Linux device driver during system boot.

eeprom_update_moitessier
------------------------
Is used to update the ID EEPROM of the Moitessier HAT.
